import { useState, useEffect } from 'react'
import { useRouter } from 'next/router'
import Link from 'next/link'
import { supabase } from '../../lib/supabaseClient'
import Spinner from '../../components/Spinner'
import PremiumModal from '../../components/PremiumModal'
import { withAuth } from '../../components/withAuth'
import { isCompanyAdmin, roleLabel } from '../../lib/permissions'
import { useProfile } from '../../context/ProfileContext'

const PERMISSION_FIELDS = [
  { key: 'can_create_tasks', label: 'Создание заданий' },
  { key: 'can_review_tasks', label: 'Проверка заданий и покупок' },
  { key: 'can_manage_employees', label: 'Добавление сотрудников' },
  { key: 'can_delete_employees', label: 'Удаление сотрудников' },
]

const emptyPermissions = { can_create_tasks: false, can_review_tasks: false, can_manage_employees: false, can_delete_employees: false }

function EmployeesPage() {
  const router = useRouter()
  const { profile: myProfile } = useProfile()
  const [companyId, setCompanyId] = useState(null)
  const [employees, setEmployees] = useState([])
  const [positions, setPositions] = useState([])
  const [companyRoles, setCompanyRoles] = useState([])
  const [loading, setLoading] = useState(true)
  const [editingEmployee, setEditingEmployee] = useState(null)
  const [editForm, setEditForm] = useState({ email: '', first_name: '', last_name: '', position_id: '', role_id: '', ...emptyPermissions })
  const [pendingInvites, setPendingInvites] = useState([])
  const [showAddModal, setShowAddModal] = useState(false)
  const [newEmployee, setNewEmployee] = useState({ email: '', first_name: '', last_name: '', position_id: '', role_id: '', ...emptyPermissions })
  const [newPositionTitle, setNewPositionTitle] = useState('')
  const [notification, setNotification] = useState({ show: false, message: '' })

  useEffect(() => {
    const init = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { router.push('/login'); return }
      const { data: profileData } = await supabase
        .from('profiles')
        .select('company_id')
        .eq('user_id', user.id)
        .single()
      if (!profileData) { router.push('/'); return }
      setCompanyId(profileData.company_id)
      await loadData(profileData.company_id)
      setLoading(false)
    }
    init()
  }, [router])

  const loadData = async (compId) => {
    const [empRes, posRes, rolesRes] = await Promise.all([
      supabase.from('profiles').select('*, positions(title)').eq('company_id', compId).is('deleted_at', null),
      supabase.from('positions').select('*').eq('company_id', compId).order('title'),
      supabase.from('roles').select('*').eq('company_id', compId).order('name')
    ])
    setEmployees(empRes.data?.filter(emp => !isCompanyAdmin(emp)) || [])
    setPositions(posRes.data || [])
    setCompanyRoles(rolesRes.data || [])
    loadPendingInvites()
  }

  const loadPendingInvites = async () => {
    const { data: { session } } = await supabase.auth.getSession()
    if (!session) return
    try {
      const res = await fetch('/api/company-admin/pending-invites', {
        headers: { Authorization: `Bearer ${session.access_token}` }
      })
      if (res.ok) setPendingInvites(await res.json())
    } catch (e) {
      // не критично для страницы
    }
  }

  const cancelInvite = async (invitationId) => {
    const { data: { session } } = await supabase.auth.getSession()
    await fetch('/api/company-admin/cancel-invite', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` },
      body: JSON.stringify({ invitationId })
    })
    loadPendingInvites()
  }

  const showNotification = (msg) => {
    setNotification({ show: true, message: msg })
    setTimeout(() => setNotification({ show: false, message: '' }), 3000)
  }

  const handleAddPosition = async () => {
    if (!newPositionTitle.trim()) return
    const { error } = await supabase.from('positions').insert({ company_id: companyId, title: newPositionTitle.trim() })
    if (!error) {
      setNewPositionTitle('')
      loadData(companyId)
      showNotification('Должность добавлена')
    } else {
      showNotification('Ошибка добавления должности')
    }
  }

  const handleAddEmployee = async () => {
    if (!newEmployee.email) return
    // Раньше здесь была прямая вставка строки в profiles без user_id и без
    // создания приглашения — сотрудник физически не мог войти в систему
    // (в проекте нигде не было кода, создающего invitations). Теперь это
    // настоящее приглашение: Supabase Auth сам отправит письмо с
    // безопасной одноразовой ссылкой, а профиль создастся при первом входе
    // сотрудника (pages/api/invitations/accept.js).
    const { data: { session } } = await supabase.auth.getSession()
    try {
      const res = await fetch('/api/company-admin/invite-employee', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${session.access_token}`
        },
        body: JSON.stringify({
          email: newEmployee.email,
          firstName: newEmployee.first_name,
          lastName: newEmployee.last_name,
          positionId: newEmployee.position_id || null,
          roleId: newEmployee.role_id || null,
          permissions: {
            can_create_tasks: newEmployee.can_create_tasks,
            can_review_tasks: newEmployee.can_review_tasks,
            can_manage_employees: newEmployee.can_manage_employees,
            can_delete_employees: newEmployee.can_delete_employees
          }
        })
      })
      const result = await res.json()
      if (!res.ok) {
        showNotification('Ошибка: ' + (result.error || 'не удалось пригласить'))
        return
      }
      setShowAddModal(false)
      setNewEmployee({ email: '', first_name: '', last_name: '', position_id: '', role_id: '', ...emptyPermissions })
      loadData(companyId)
      showNotification('Приглашение отправлено на ' + newEmployee.email)
    } catch (err) {
      showNotification('Внутренняя ошибка сервера')
    }
  }

  const handleEditEmployee = (emp) => {
    setEditingEmployee(emp)
    setEditForm({
      email: emp.email || '',
      first_name: emp.first_name || '',
      last_name: emp.last_name || '',
      position_id: emp.position_id || '',
      role_id: emp.role_id || '',
      can_create_tasks: !!emp.can_create_tasks,
      can_review_tasks: !!emp.can_review_tasks,
      can_manage_employees: !!emp.can_manage_employees,
      can_delete_employees: !!emp.can_delete_employees,
    })
  }

  const handleSaveEdit = async () => {
    if (!editingEmployee) return
    const { error } = await supabase.from('profiles').update({
      email: editForm.email,
      first_name: editForm.first_name,
      last_name: editForm.last_name,
      position_id: editForm.position_id || null,
      role_id: editForm.role_id || null,
      can_create_tasks: editForm.can_create_tasks,
      can_review_tasks: editForm.can_review_tasks,
      can_manage_employees: editForm.can_manage_employees,
      can_delete_employees: editForm.can_delete_employees,
      display_name: `${editForm.first_name} ${editForm.last_name}`.trim() || editForm.email
    }).eq('id', editingEmployee.id)
    if (!error) {
      setEditingEmployee(null)
      loadData(companyId)
      showNotification('Сотрудник обновлён')
    } else {
      showNotification('Ошибка сохранения')
    }
  }

  const handleDeleteEmployee = async (empId) => {
    if (!myProfile?.can_delete_employees && !isCompanyAdmin(myProfile)) {
      showNotification('У вас нет прав на удаление сотрудников')
      return
    }
    await supabase.from('profiles').update({ deleted_at: new Date().toISOString() }).eq('id', empId)
    loadData(companyId)
    showNotification('Сотрудник удалён')
  }

  const canDelete = myProfile?.can_delete_employees || isCompanyAdmin(myProfile)

  if (loading) return <div className="flex justify-center items-center py-8"><Spinner /></div>

  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <Link href="/company-admin" className="text-gray-400 hover:text-white text-sm mb-6 inline-block">← Назад</Link>
      <h1 className="text-2xl font-bold mb-6" style={{ color: '#d4af37' }}>Управление командой</h1>

      <div className="flex items-center gap-2 mb-4">
        <input
          type="text"
          className="input-field w-48"
          placeholder="Новая должность"
          value={newPositionTitle}
          onChange={e => setNewPositionTitle(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleAddPosition()}
        />
        <button onClick={handleAddPosition} className="btn-outline text-sm px-3 py-2">Добавить должность</button>
        <button onClick={() => setShowAddModal(true)} className="btn-gold text-sm px-4 py-2 ml-auto">Добавить сотрудника</button>
      </div>

      <div className="pastel-card overflow-auto max-h-[70vh]">
        <table className="w-full text-left text-sm">
          <thead className="text-gray-400 border-b border-gray-700">
            <tr>
              <th className="py-2 pr-4">Имя</th>
              <th className="py-2 pr-4">Email</th>
              <th className="py-2 pr-4">Должность</th>
              <th className="py-2 pr-4">Роль</th>
              <th className="py-2">Действия</th>
            </tr>
          </thead>
          <tbody>
            {employees.map(emp => (
              <tr key={emp.id} className="border-b border-gray-800 hover:bg-gray-800/50 cursor-pointer" onClick={() => handleEditEmployee(emp)}>
                <td className="py-3 pr-4">{emp.display_name || emp.email}</td>
                <td className="py-3 pr-4 text-gray-400">{emp.email}</td>
                <td className="py-3 pr-4">{emp.positions?.title || '—'}</td>
                <td className="py-3 pr-4">{roleLabel(emp)}</td>
                <td className="py-3" onClick={e => e.stopPropagation()}>
                  {canDelete && (
                    <button onClick={() => handleDeleteEmployee(emp.id)} className="text-xs text-red-400 hover:text-red-300">Удалить</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {pendingInvites.length > 0 && (
        <div className="pastel-card mt-6 p-4">
          <h3 className="text-sm text-gray-400 mb-3">Ожидают активации ({pendingInvites.length})</h3>
          <ul className="space-y-2">
            {pendingInvites.map(inv => (
              <li key={inv.id} className="flex justify-between items-center text-sm text-gray-300">
                <span>{inv.email}</span>
                <span className="flex items-center gap-3">
                  <span className="text-xs text-gray-500">
                    приглашён {new Date(inv.created_at).toLocaleDateString('ru')}
                  </span>
                  <button
                    onClick={() => cancelInvite(inv.id)}
                    className="text-xs text-red-400 hover:text-red-300"
                  >
                    Отменить
                  </button>
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Модалки остаются без изменений в разметке — добавлены чекбоксы прав,
          см. PERMISSION_FIELDS. Разметку модалок в проекте нужно дополнить
          полями role_id (select из companyRoles) и PERMISSION_FIELDS.map(...) —
          логика состояния (editForm/newEmployee) уже это поддерживает. */}
    </div>
  )
}

export default withAuth(EmployeesPage, { permission: 'can_manage_employees' })
